const express = require('express');
const app = express();
const port = 3000; // You can change this to any port you prefer
const fs = require('fs');

// Define a simple route
app.get('/pokemons', (req, res) => {
  console.log("in getter")
  fs.readFile('pokemon.json', 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error reading JSON file');
    }

    try {
      // Parse the JSON data
      const jsonData = JSON.parse(data);
      res.json(jsonData);
    } catch (error) {
      console.error(error);
      res.status(500).send('Error parsing JSON data');
    }
  });
});

app.post('/pokemons', (req, res) => {
  const name = req.body.name;

  if (!name) {
    return res.status(400).send('Name is required');
  }

  const id = pokemons[pokemons.length - 1].id + 1 

  const newPokemon = {
    id,
    name,
  };

  pokemons.push(newPokemon);

  fs.writeFile('pokemon.json', JSON.stringify(pokemons), (err) => {
    if (err) {
      console.error(err);
    }
    res.json(newPokemon);
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
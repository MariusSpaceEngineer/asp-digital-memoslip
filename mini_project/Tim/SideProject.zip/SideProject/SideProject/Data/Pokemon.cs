﻿using System.Text.Json.Serialization;

namespace SideProject.Data
{
    public class Pokemon
    {
        public int? Id { get; set; }

        public string? Name { get; set; }

        public List<string>? Type { get; set; }
    }
}

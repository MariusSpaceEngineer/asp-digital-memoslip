﻿namespace SideProject.Data
{
    public class PokemonList
    {
        public List<Pokemon>? Pokemons { get; set; }         
    }
}

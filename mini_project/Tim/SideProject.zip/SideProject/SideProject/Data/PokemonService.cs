﻿namespace SideProject.Data
{
    public class PokemonService
    {
        private HttpClient httpClient;

        public PokemonService(HttpClient httpClient)
        {
            this.httpClient = httpClient;
        }


        public async Task<PokemonList> GetPokemonList()
        {

            var response = await httpClient.GetFromJsonAsync<PokemonList>("/pokemons");
    
            return response;
        }
    }
}
